# 插件开发

该插件是对收集上来的用例集的名字进行中文编码以及
单独执行某个模块的用例集，比如：add

#打包需要安装的插件
1、setuptools
2、pip install wheel